{{/*
Deletes keys from the_map which exist in override_map.

Usage:
  {{- include "common-tpl-lib-2.7.0.override" (dict "the_map" my_map "override_map" my_override_map) }}
*/}}
{{- define "common-tpl-lib-2.7.0.override" }}
{{- range $key, $value := $.override_map }}
{{- $_ := unset $.the_map $key }}
{{- end }}
{{- end }}

{{/*
Calls several override map pairs. Feel free to add more for volumes etc.

Usage:
  {{- include "common-tpl-lib-2.7.0.override.maps" . }}
*/}}
{{- define "common-tpl-lib-2.7.0.override.maps" }}
{{- if and .Values.configmaps .Values.configmaps.env .Values.secrets .Values.secrets.env }}
{{- include "common-tpl-lib-2.7.0.override" (dict "the_map" $.Values.configmaps.env "override_map" $.Values.secrets.env) }}
{{- end }}
{{- if and .Values.configmaps .Values.configmaps.env .Values.externalEnv }}
{{- include "common-tpl-lib-2.7.0.override" (dict "the_map" $.Values.configmaps.env "override_map" $.Values.externalEnv) }}
{{- end }}
{{- if and .Values.secrets .Values.secrets.env .Values.externalEnv }}
{{- include "common-tpl-lib-2.7.0.override" (dict "the_map" $.Values.secrets.env "override_map" $.Values.externalEnv) }}
{{- end }}
{{- end }}

{{/*
Recursively substitute all strings in the given structure with it's "tpl" result.

Usage:
  {{- include "common-tpl-lib-2.7.0.map.eval.replace" (dict "root" $ "cursor" $.Values) }}
*/}}
{{- define "common-tpl-lib-2.7.0.map.eval.replace" -}}
{{- $root := $.root }}
{{- $cursor := $.cursor }}
{{- if not (kindIs "map" $cursor) }}
{{- fail (print "argument must be of kind 'map' and I got a " (kindOf $cursor)) }}
{{- end }}
{{- range $key, $value := $cursor }}
{{- if kindIs "string" . }}
{{- $result := dict "value" . "type" "" }}
{{- if contains "{{" . }}
{{- range $i := until 10 }}
{{- $in := $result.value }}
{{- if and (kindIs "string" $in) (contains "{{" $in) }}
{{/* preserve type cast */}}
{{- if regexMatch "[|] *toYaml *[}][}]$" $in }}
{{- $_ := set $result "value" (tpl $in $root) }}
{{- $_3 := set $result "type" "yaml" }}
{{- else if regexMatch "[|] *int *[}][}]$" $in }}
{{- $in := mustRegexReplaceAllLiteral "[|] *int *[}][}]$" $in "}}" }}
{{- $_ := set $result "value" (tpl $in $root) }}
{{- $_3 := set $result "type" "int" }}
{{- else }}
{{- $_ := set $result "value" (tpl $in $root) }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{/* adjust type */}}
{{- $in := $result.value }}
{{- $type := $result.type }}
{{- if eq $type "yaml" }}
{{- $_ := set $result "value" ($in | fromYaml) }}
{{- else if eq $type "int" }}
{{- $_ := set $result "value" ($in | atoi) }}
{{- else }}
{{- end }}
{{/* This is needed to keep the instruction for later interpretation as described in the Readme.md
(See "mark Go-Tpl-Functions for later interpretation" */}}
{{- $out := $result.value }}
{{- if kindIs "string" $out }}
{{- $_ := set $result "value" (mustRegexReplaceAllLiteral "{\\\\{" $out "{{") }}
{{- end }}
{{- $_ := set $cursor $key $result.value }}
{{- else if kindIs "map" . }}
{{- include "common-tpl-lib-2.7.0.map.eval.replace" (dict "root" $root "cursor" .) }}
{{- else if kindIs "slice" . }}
{{- $the := dict "list" list }}
{{- range . }}
{{- $map := dict "value" . }}
{{- include "common-tpl-lib-2.7.0.map.eval.replace" (dict "root" $root "cursor" $map) }}
{{- $_ := set $the "list" (append $the.list $map.value) }}
{{- end }}
{{- $_ := set $cursor $key $the.list }}
{{- else if kindIs "bool" . }}
{{- else if kindIs "float64" . }}
{{- else if kindIs "invalid" . }}
{{- else if kindIs "int" . }}
{{- else if kindIs "int64" . }}
{{- else }}
{{- fail (print "unexpected kind " (kindOf .) ": " .) }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Recursively substitute all strings in .Values with it's "tpl" result.

Usage:
  {{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
*/}}
{{- define "common-tpl-lib-2.7.0.tpl.all.values" -}}
{{- if hasKey .Values "commons-values-evaluated" }}
{{- $_ := set $.Values "commons-values-evaluated" (add1 (get $.Values "commons-values-evaluated")) }}
{{- else }}
{{- $_ := set $.Values "commons-values-evaluated" 1 }}
{{- include "common-tpl-lib-2.7.0.map.eval.replace" (dict "root" $ "cursor" $.Values) }}
{{- include "common-tpl-lib-2.7.0.override.maps" . }}
{{- end }}
{{- end }}

{{/*
Supporting function. Only to be used lib-internally. Applies affinity
configuration with default convenience configuration options.

Usage:
  To be used in the deployment template function with:
  {{- include "common-tpl-lib-2.7.0.affinity" . }}
*/}}
{{- define "common-tpl-lib-2.7.0.affinity" -}}
{{- $affinity := (.Values.affinity | default dict) }}
{{- $enabled := true }}
{{- if hasKey $affinity "enabled" }}
{{- $enabled = $affinity.enabled | toString | eq "true" }}
{{- end }}
{{- $preset := $affinity.preset | default "podAntiAffinity:preferred" }}
{{- $enforcePreset := false }}
{{- if hasKey $affinity "enforcePreset" }}
{{- $enforcePreset = $affinity.enforcePreset | toString | eq "true" }}
{{- end }}
{{- $customConfigFound := or (not (empty $affinity.podAntiAffinity)) (not (empty $affinity.podAffinity)) (not (empty $affinity.nodeAffinity)) }}
{{- if $enabled }}
{{- if $customConfigFound | and (not $enforcePreset) }}
{{- $_ := unset $affinity "enabled" }}
{{- $_ := unset $affinity "preset" }}
{{- $_ := unset $affinity "enforcePreset" }}
affinity:
{{- $affinity | toYaml | nindent 2 }}
{{- else if $preset | eq "podAntiAffinity:preferred" }}
affinity:
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - podAffinityTerm:
          labelSelector:
            matchLabels:
              {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 14 }}
          {{- /* Use anti-affinity w.r.t. node to be scheduled on */}}
          topologyKey: kubernetes.io/hostname
        weight: 100
{{- else if $preset | eq "podAntiAffinity:required" }}
affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchLabels:
            {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 12 }}
        topologyKey: kubernetes.io/hostname
        {{- /* TODO: With this, only Pods from a given rollout are taken into consideration when calculating
        pod affinity. But it is still a beta feature. For details, see
        https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#matchlabelkeys

        matchLabelKeys:
          - pod-template-hash
        */}}
{{- else }}
{{ fail (print "unsupported value for field affinity.preset: " $preset) }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard deployment.
*/}}
{{- define "common-tpl-lib-2.7.0.deployment" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- include "common-tpl-lib-2.7.0.resourceValidations" . }}
{{- include "common-tpl-lib-2.7.0.probeValidations" . }}
{{- if eq (dig "workload" "type" "Deployment" .Values.AsMap) "Deployment" }}
# Library definition: common-tpl-lib-2.7.0.deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
  {{- with (dig "workload" "annotations" (dict) .Values.AsMap) }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- if ne (.Values.autoscaling.enabled | default "false" | toString) "true" }}
  {{- $replicaCount :=  1 }}
  {{- if ne .Values.replicaCount nil }}
  {{- $replicaCount = int .Values.replicaCount }}
  {{- end }}
  replicas: {{ $replicaCount }}
  {{- end }}
  selector:
    matchLabels:
      {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 6 }}
  {{- if .Values.deploymentStrategy }}
  strategy:
    {{- toYaml .Values.deploymentStrategy | nindent 4 }}
  {{- end }}
  template:
    metadata:
      annotations:
        checksum/config: {{ print (include "common-tpl-lib-2.7.0.configmaps.env" .) (include "common-tpl-lib-2.7.0.configmaps.files" .) (include "common-tpl-lib-2.7.0.secrets.env" .) (include "common-tpl-lib-2.7.0.secrets.files" .) | sha256sum }}
        {{- with .Values.podAnnotations }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
      labels:
        {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 8 }}
        {{- with .Values.podLabels }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
    spec:
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      serviceAccountName: {{ include "common-tpl-lib-2.7.0.serviceAccountName" . }}
      securityContext:
        {{- toYaml .Values.podSecurityContext | nindent 8 }}
      {{- if .Values.initContainers }}
      initContainers:
        {{- range $key, $value := .Values.initContainers }}
        - name: {{ $key }}
          {{- toYaml $value | nindent 10 }}
        {{- end }}
      {{- end }}
      containers:
        - name: {{ .Chart.Name }}
          securityContext:
            {{- toYaml .Values.securityContext | nindent 12 }}
          image: "{{ if .Values.image.repository }}{{ trimSuffix "/" .Values.image.repository }}/{{ end }}{{ .Values.image.name }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
          imagePullPolicy: {{ .Values.image.pullPolicy }}
          {{- with .Values.image.command }}
          command:
          {{- range $cmd := . }}
            - {{ $cmd }}
          {{- end }}
          {{- end }}
          {{- with .Values.image.args }}
          args:
          {{- range $arg := . }}
            - {{ $arg }}
          {{- end }}
          {{- end }}
          {{- with .Values.lifecycle }}
          lifecycle:
            {{- toYaml (omit . "terminationGracePeriodSeconds") | nindent 12 }}
          {{- end }}
          ports:
            {{- range $key, $value := .Values.service.ports }}
            - name: {{ $key }}
              containerPort: {{ coalesce $value.port $value.containerPort 8080 }}
              protocol: {{ coalesce $value.protocol "TCP" }}
            {{- end }}
          {{- with .Values.probes }}
          {{- if eq (dig "enabled" "true" . | toString) "true" }}
          {{- toYaml (omit . "enabled") | nindent 10 }}
          {{- end }}
          {{- end }}
          resources:
            {{- with .Values.resources }}
            {{- if eq (dig "enabled" "true" . | toString) "true" }}
            {{- toYaml (omit . "enabled") | nindent 12 }}
            {{- end }}
            {{- end }}
          {{- if or .Values.configmaps.env .Values.secrets.env .Values.externalEnv }}
          env:
            {{- range $key, $value := .Values.configmaps.env }}
            - name: {{ $key }}
              valueFrom:
                configMapKeyRef:
                  name: {{ include "common-tpl-lib-2.7.0.fullname" $ }}-env-configmap
                  key: {{ $key }}
            {{- end }}
            {{- range $key, $value := .Values.secrets.env }}
            - name: {{ $key }}
              valueFrom:
                secretKeyRef:
                  name: {{ include "common-tpl-lib-2.7.0.fullname" $ }}-env-secret
                  key: {{ $key }}
            {{- end }}
            {{- range $key, $value := .Values.externalEnv }}
            - name: {{ $key }}
              valueFrom:
                {{- toYaml $value | nindent 16 }}
            {{- end }}
          {{- end }}
          volumeMounts:
            {{- range $key, $value := .Values.configmaps.files }}
            - mountPath: {{ $value.path }}
              name: files
              subPath: {{ $key }}
            {{- end }}
            {{- range $key, $value := .Values.secrets.files }}
            - mountPath: {{ $value.path }}
              name: files
              subPath: {{ $key }}
            {{- end }}
            {{- range $key, $value := .Values.volumes }}
            {{- range $value.mounts }}
            - {{ toYaml (set . "name" $key) | nindent 14 | trim }}
            {{- end }}
            {{- end }}
      volumes:
        {{- if or .Values.configmaps.files .Values.secrets.files }}
        - name: files
          projected:
            sources:
              {{- if .Values.secrets.files }}
              - secret:
                  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}-files-secret
                  items:
                    {{- range $key, $value := .Values.secrets.files }}
                    - key: {{ $key }}
                      path: {{ $key }}
                      {{- if hasKey $value "mode" }}
                      mode: {{ $value.mode }}
                      {{- end }}
                    {{- end }}
              {{- end }}
              {{- if .Values.configmaps.files }}
              - configMap:
                  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}-files-configmap
                  items:
                    {{- range $key, $value := .Values.configmaps.files }}
                    - key: {{ $key }}
                      path: {{ $key }}
                      {{- if hasKey $value "mode" }}
                      mode: {{ $value.mode }}
                      {{- end }}
                    {{- end }}
              {{- end }}
            defaultMode: 0770
        {{- end }}
        {{- range $key, $value := .Values.volumes }}
        - name: {{ $key }}
          {{- if $value.claimName }}
          persistentVolumeClaim:
            claimName: {{ $value.claimName }}
          {{- else }}
          {{- toYaml (omit $value "mounts" "volume" "claim") | nindent 10 }}
          {{- end }}
        {{- end }}
      {{- with .Values.lifecycle }}
      {{- if .terminationGracePeriodSeconds }}
      terminationGracePeriodSeconds: {{ .terminationGracePeriodSeconds }}
      {{- end }}
      {{- end }}
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- include "common-tpl-lib-2.7.0.affinity" . | nindent 6 }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard stateful set.
*/}}
{{- define "common-tpl-lib-2.7.0.statefulset" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- include "common-tpl-lib-2.7.0.resourceValidations" . }}
{{- include "common-tpl-lib-2.7.0.probeValidations" . }}
{{- if eq (dig "workload" "type" "Deployment" .Values.AsMap) "StatefulSet" }}
# Library definition: common-tpl-lib-2.7.0.statefulset
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
  {{- with (dig "workload" "annotations" (dict) .Values.AsMap) }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  serviceName: {{ include "common-tpl-lib-2.7.0.fullname" . }}
  {{- if ne (.Values.autoscaling.enabled | default "false" | toString) "true" }}
  {{- $replicaCount :=  1 }}
  {{- if ne .Values.replicaCount nil }}
  {{- $replicaCount = int .Values.replicaCount }}
  {{- end }}
  replicas: {{ .Values.replicaCount }}
  {{- end }}
  selector:
    matchLabels:
      {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 6 }}
  {{- if .Values.deploymentStrategy }}
  updateStrategy:
    {{- toYaml .Values.deploymentStrategy | nindent 4 }}
  {{- end }}
  volumeClaimTemplates:
    {{- range $key, $value := .Values.volumes }}
    {{- if and (dig "claim" "accessModes" list $value) (has "ReadWriteOnce" $value.claim.accessModes) }}
  - metadata:
      name: {{ $key }}
    spec:
      {{- toYaml $value.claim | nindent 6 }}
    {{- end }}
    {{- end }}
  template:
    metadata:
      annotations:
        checksum/config: {{ print (include "common-tpl-lib-2.7.0.configmaps.env" .) (include "common-tpl-lib-2.7.0.configmaps.files" .) (include "common-tpl-lib-2.7.0.secrets.env" .) (include "common-tpl-lib-2.7.0.secrets.files" .) | sha256sum }}
        {{- with .Values.podAnnotations }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
      labels:
        {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 8 }}
        {{- with .Values.podLabels }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
    spec:
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      serviceAccountName: {{ include "common-tpl-lib-2.7.0.serviceAccountName" . }}
      securityContext:
        {{- toYaml .Values.podSecurityContext | nindent 8 }}
      {{- if .Values.initContainers }}
      initContainers:
        {{- range $key, $value := .Values.initContainers }}
        - name: {{ $key }}
          {{- toYaml $value | nindent 10 }}
        {{- end }}
      {{- end }}
      containers:
        - name: {{ .Chart.Name }}
          securityContext:
            {{- toYaml .Values.securityContext | nindent 12 }}
          image: "{{ if .Values.image.repository }}{{ trimSuffix "/" .Values.image.repository }}/{{ end }}{{ .Values.image.name }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
          imagePullPolicy: {{ .Values.image.pullPolicy }}
          {{- with .Values.image.command }}
          command:
          {{- range $cmd := . }}
            - {{ $cmd }}
          {{- end }}
          {{- end }}
          {{- with .Values.image.args }}
          args:
          {{- range $arg := . }}
            - {{ $arg }}
          {{- end }}
          {{- end }}
          {{- with .Values.lifecycle }}
          lifecycle:
            {{- toYaml (omit . "terminationGracePeriodSeconds") | nindent 12 }}
          {{- end }}
          ports:
            {{- range $key, $value := .Values.service.ports }}
            - name: {{ $key }}
              containerPort: {{ coalesce $value.port $value.containerPort 8080 }}
              protocol: {{ coalesce $value.protocol "TCP" }}
            {{- end }}
          {{- with .Values.probes }}
          {{- if eq (dig "enabled" "true" . | toString) "true" }}
          {{- toYaml (omit . "enabled") | nindent 10 }}
          {{- end }}
          {{- end }}
          resources:
            {{- with .Values.resources }}
            {{- if eq (dig "enabled" "true" . | toString) "true" }}
            {{- toYaml (omit . "enabled") | nindent 12 }}
            {{- end }}
            {{- end }}
          {{- if or .Values.configmaps.env .Values.secrets.env .Values.externalEnv }}
          env:
            {{- range $key, $value := .Values.configmaps.env }}
            - name: {{ $key }}
              valueFrom:
                configMapKeyRef:
                  name: {{ include "common-tpl-lib-2.7.0.fullname" $ }}-env-configmap
                  key: {{ $key }}
            {{- end }}
            {{- range $key, $value := .Values.secrets.env }}
            - name: {{ $key }}
              valueFrom:
                secretKeyRef:
                  name: {{ include "common-tpl-lib-2.7.0.fullname" $ }}-env-secret
                  key: {{ $key }}
            {{- end }}
            {{- range $key, $value := .Values.externalEnv }}
            - name: {{ $key }}
              valueFrom:
                {{- toYaml $value | nindent 16 }}
            {{- end }}
          {{- end }}
          volumeMounts:
            {{- range $key, $value := .Values.configmaps.files }}
            - mountPath: {{ $value.path }}
              name: files
              subPath: {{ $key }}
            {{- end }}
            {{- range $key, $value := .Values.secrets.files }}
            - mountPath: {{ $value.path }}
              name: files
              subPath: {{ $key }}
            {{- end }}
            {{- range $key, $value := .Values.volumes }}
            {{- range $value.mounts }}
            - {{ toYaml (set . "name" $key) | nindent 14 | trim }}
            {{- end }}
            {{- end }}
      volumes:
        {{- if or .Values.configmaps.files .Values.secrets.files }}
        - name: files
          projected:
            sources:
              {{- if .Values.secrets.files }}
              - secret:
                  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}-files-secret
                  items:
                    {{- range $key, $value := .Values.secrets.files }}
                    - key: {{ $key }}
                      path: {{ $key }}
                      {{- if hasKey $value "mode" }}
                      mode: {{ $value.mode }}
                      {{- end }}
                    {{- end }}
              {{- end }}
              {{- if .Values.configmaps.files }}
              - configMap:
                  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}-files-configmap
                  items:
                    {{- range $key, $value := .Values.configmaps.files }}
                    - key: {{ $key }}
                      path: {{ $key }}
                      {{- if hasKey $value "mode" }}
                      mode: {{ $value.mode }}
                      {{- end }}
                    {{- end }}
              {{- end }}
            defaultMode: 0770
        {{- end }}
        {{- range $key, $value := .Values.volumes }}
        {{- if not (and (dig "claim" "accessModes" list $value) (has "ReadWriteOnce" $value.claim.accessModes)) }}
        - name: {{ $key }}
          {{- if $value.claimName }}
          persistentVolumeClaim:
            claimName: {{ $value.claimName }}
          {{- else }}
          {{- toYaml (omit $value "mounts" "volume" "claim") | nindent 10 }}
          {{- end }}
        {{- end }}
        {{- end }}
      {{- with .Values.lifecycle }}
      {{- if .terminationGracePeriodSeconds }}
      terminationGracePeriodSeconds: {{ .terminationGracePeriodSeconds }}
      {{- end }}
      {{- end }}
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- include "common-tpl-lib-2.7.0.affinity" . | nindent 6 }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard horizontal pod autoscaler.
*/}}
{{- define "common-tpl-lib-2.7.0.hpa" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- if eq (.Values.autoscaling.enabled | default "false" | toString) "true" }}
# Library definition: common-tpl-lib-2.7.0.hpa
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: {{ include "common-tpl-lib-2.7.0.fullname" . }}
  minReplicas: {{ .Values.autoscaling.minReplicas }}
  maxReplicas: {{ .Values.autoscaling.maxReplicas }}
  metrics:
    {{- if .Values.autoscaling.targetCPUUtilizationPercentage }}
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: {{ .Values.autoscaling.targetCPUUtilizationPercentage }}
    {{- end }}
    {{- if .Values.autoscaling.targetMemoryUtilizationPercentage }}
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: {{ .Values.autoscaling.targetMemoryUtilizationPercentage }}
    {{- end }}
  {{- if .Values.autoscaling.behavior }}
  behavior:
    {{- toYaml .Values.autoscaling.behavior | nindent 4 }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard ingress and all extra ingresses.
*/}}
{{- define "common-tpl-lib-2.7.0.ingress" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
# Library definition: common-tpl-lib-2.7.0.ingress
{{- $fullName := include "common-tpl-lib-2.7.0.fullname" . -}}
{{- range $name, $ingress := (merge (dict $fullName .Values.ingress) (dig "extraIngresses" (dict) .Values.AsMap)) }}
---
{{- if eq ($ingress.enabled | default "false" | toString) "true" -}}
{{- if and $ingress.className (not (semverCompare ">=1.18-0" $.Capabilities.KubeVersion.GitVersion)) }}
  {{- if not (hasKey $ingress.annotations "kubernetes.io/ingress.class") }}
  {{- $_ := set $ingress.annotations "kubernetes.io/ingress.class" $ingress.className}}
  {{- end }}
{{- end }}
{{/* Do not include a dash "-" to reduce whitespaces in the following line before the "if", because
this leads to errors with a bug in helm lint. */}}
{{ if semverCompare ">=1.19-0" $.Capabilities.KubeVersion.GitVersion -}}
apiVersion: networking.k8s.io/v1
{{ else if semverCompare ">=1.14-0" $.Capabilities.KubeVersion.GitVersion -}}
apiVersion: networking.k8s.io/v1beta1
{{ else -}}
apiVersion: extensions/v1beta1
{{- end -}}
kind: Ingress
metadata:
  name: {{ $name }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" $ | nindent 4 }}
  {{- with $ingress.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- if and $ingress.className (semverCompare ">=1.18-0" $.Capabilities.KubeVersion.GitVersion) }}
  ingressClassName: {{ $ingress.className }}
  {{- end }}
  {{- if $ingress.tls }}
  tls:
    {{- range $ingress.tls }}
    - hosts:
        {{- range .hosts }}
        - {{ . | quote }}
        {{- end }}
      secretName: {{ .secretName }}
    {{- end }}
  {{- end }}
  rules:
    {{- range $ingress.hosts }}
    - host: {{ .host | quote }}
      http:
        paths:
          {{- range .paths }}
          {{- if eq (dig "enabled" "true" . | toString) "true" }}
          - path: {{ .path }}
            {{- if and .pathType (semverCompare ">=1.18-0" $.Capabilities.KubeVersion.GitVersion) }}
            pathType: {{ .pathType }}
            {{- end }}
            backend:
              {{- if semverCompare ">=1.19-0" $.Capabilities.KubeVersion.GitVersion }}
              service:
                name: {{ dig "service" $fullName . }}
                port:
                  {{ ternary "name" "number" (kindIs "string" .port) }}: {{ .port }}
              {{- else }}
              serviceName: {{ dig "service" $fullName . }}
              servicePort: {{ .port }}
              {{- end }}
          {{- end }}
          {{- end }}
    {{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Define the standard release notes.
*/}}
{{- define "common-tpl-lib-2.7.0.notes" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- $serviceType := coalesce .Values.service.type "ClusterIP" }}
Get the application URL by running these commands:
{{- if .Values.ingress.enabled }}
{{- range $host := .Values.ingress.hosts }}
  {{- range .paths }}
  http{{ if $.Values.ingress.tls }}s{{ end }}://{{ $host.host }}{{ .path }}
  {{- end }}
{{- end }}
{{- else if contains "NodePort" $serviceType }}
  export NODE_PORT=$(kubectl get --namespace {{ .Release.Namespace }} -o jsonpath="{.spec.ports[0].nodePort}" services {{ include "common-tpl-lib-2.7.0.fullname" . }})
  export NODE_IP=$(kubectl get nodes --namespace {{ .Release.Namespace }} -o jsonpath="{.items[0].status.addresses[0].address}")
  echo http://$NODE_IP:$NODE_PORT
{{- else if contains "LoadBalancer" $serviceType }}
     NOTE: It may take a few minutes for the LoadBalancer IP to be available.
           You can watch the status of by running 'kubectl get --namespace {{ .Release.Namespace }} svc -w {{ include "common-tpl-lib-2.7.0.fullname" . }}'
  export SERVICE_IP=$(kubectl get svc --namespace {{ .Release.Namespace }} {{ include "common-tpl-lib-2.7.0.fullname" . }} --template "{{"{{ range (index .status.loadBalancer.ingress 0) }}{{.}}{{ end }}"}}")
  echo http://$SERVICE_IP:{{ .Values.service.port }}
{{- else if contains "ClusterIP" $serviceType }}
{{- /*  export POD_NAME=$(kubectl get pods --namespace {{ .Release.Namespace }} -l "app.kubernetes.io/name={{ include "common-tpl-lib-2.7.0.name" . }},app.kubernetes.io/instance={{ .Release.Name }}" -o jsonpath="{.items[0].metadata.name}")*/}}
{{- /*  export CONTAINER_PORT=$(kubectl get pod --namespace {{ .Release.Namespace }} $POD_NAME -o jsonpath="{.spec.containers[0].ports[0].containerPort}")*/}}
{{- /*  echo "Visit http://127.0.0.1:8080 to use your application"*/}}
{{- /*  kubectl --namespace {{ .Release.Namespace }} port-forward $POD_NAME 8080:$CONTAINER_PORT*/}}
  {{- range $key, $value := .Values.service.ports }}
  kubectl --namespace {{ $.Release.Namespace }} port-forward service/{{ include "common-tpl-lib-2.7.0.fullname" $ }} {{ $value.port }}:{{ $value.port }}
  {{- $port := $value.port }}
  {{- range $value.contexts }}
  echo "Visit http://localhost:{{ $port }}{{ . }}"
  {{- end }}
  {{- end }}
{{- end }}

Direct service calls with port forwarding:
  {{- range $key, $value := .Values.service.ports }}
  {{- $port := $value.port }}
  {{- range $value.contexts }}
  echo "https://rancher.cib.de/k8s/clusters/c-tsgpx/api/v1/namespaces/{{ $.Release.Namespace }}/services/http:{{ include "common-tpl-lib-2.7.0.fullname" $ }}:{{ $port }}/proxy{{ . }}"
  {{- end }}
  {{- end }}
{{- end }}

{{/*
Define the standard service.
*/}}
{{- define "common-tpl-lib-2.7.0.service" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
# Library definition: common-tpl-lib-2.7.0.service
apiVersion: v1
kind: Service
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
  {{- with .Values.service.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  type: {{ coalesce .Values.service.type "ClusterIP" }}
  ports:
    {{- range $key, $value := .Values.service.ports }}
    - name: {{ $key }}
      port: {{ coalesce $value.port 8080 }}
      targetPort: {{ coalesce $value.containerPort $value.port 8080 }}
      protocol: {{ coalesce $value.protocol "TCP" }}
    {{- end }}
  selector:
    {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 4 }}
{{- end }}

{{/*
Define the standard service account.
*/}}
{{- define "common-tpl-lib-2.7.0.serviceaccount" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- if eq (.Values.serviceAccount.create | default "false" | toString) "true" -}}
# Library definition: common-tpl-lib-2.7.0.serviceaccount
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ include "common-tpl-lib-2.7.0.serviceAccountName" . }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
  {{- with .Values.serviceAccount.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
automountServiceAccountToken: {{ .Values.serviceAccount.automount }}
{{- end }}
{{- end }}

{{/*
Define a standard persistent volume.
*/}}
{{- define "common-tpl-lib-2.7.0.pv" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- range $key, $value := .Values.volumes }}
{{- if hasKey $value "volume" }}
---
# Library definition: common-tpl-lib-2.7.0.pv
apiVersion: v1
kind: PersistentVolume
metadata:
  name: {{ $.Release.Namespace }}-{{ include "common-tpl-lib-2.7.0.fullname" $ }}-{{ $value.volume.name }}
spec:
  {{- omit $value.volume "name" | toYaml | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard persistent volume claim.
*/}}
{{- define "common-tpl-lib-2.7.0.pvc" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- range $key, $value := .Values.volumes }}
{{- if hasKey $value "claim" }}
{{- if or ((ne (dig "workload" "type" "Deployment" $.Values.AsMap) "StatefulSet")) (not (and (dig "claim" "accessModes" list $value) (has "ReadWriteOnce" $value.claim.accessModes))) }}
---
# Library definition: common-tpl-lib-2.7.0.pvc
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: {{ $value.claimName }}
spec:
  {{- toYaml $value.claim | nindent 2 }}
  {{- /*
  It is necessary to allow PVC definitions which entirely omit the key `storageClassName` without
  forcing them to associate this PVC with a PV that is also created by this lib. Such definitions
  that omit `storageClassName` may be desired as they will cause dynamic PV provisioning.
  More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes/#class-1

  At the same time, it must be allowed to declare `storageClassName: ""` and associate with an
  externally (non-lib-)defined PV, see e.g.
  https://kubernetes.io/docs/concepts/storage/persistent-volumes/#reserving-a-persistentvolume
  */ -}}
  {{- if not $value.claim.storageClassName | and (hasKey $value "volume") }}
  volumeName: {{ $.Release.Namespace }}-{{ include "common-tpl-lib-2.7.0.fullname" $ }}-{{ $value.volume.name }}
  {{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard configmap for the environment.
*/}}
{{- define "common-tpl-lib-2.7.0.configmaps.env" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- if .Values.configmaps.env }}
# Library definition: common-tpl-lib-2.7.0.configmaps.env
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}-env-configmap
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
data:
  {{- range $key, $value := .Values.configmaps.env }}
  {{ $key }}: |-
    {{- toString $value | nindent 4 }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard configmap for the files.
*/}}
{{- define "common-tpl-lib-2.7.0.configmaps.files" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- if .Values.configmaps.files }}
# Library definition: common-tpl-lib-2.7.0.configmaps.files
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}-files-configmap
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
data:
  {{- range $key, $value := .Values.configmaps.files }}
  {{ $key }}: |-
    {{- toString $value.value | nindent 4 }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard secret for the environment.
*/}}
{{- define "common-tpl-lib-2.7.0.secrets.env" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- if .Values.secrets.env }}
# Library definition: common-tpl-lib-2.7.0.secrets.env
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}-env-secret
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
data:
  {{- range $key, $value := .Values.secrets.env }}
  {{ $key }}: "{{ toString $value | b64enc }}"
  {{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard secret for the files.
*/}}
{{- define "common-tpl-lib-2.7.0.secrets.files" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- if .Values.secrets.files }}
# Library definition: common-tpl-lib-2.7.0.secrets.files
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}-files-secret
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
data:
  {{- range $key, $value := .Values.secrets.files }}
  {{- /* Optionally, the users of the library may pre-encode their values in
  base64. In that case, we skip the encoding here to avoid duplication. To use
  this feature, the key-value pair `isBase64: true` has to be set */}}
  {{- if eq ($value | dig "isBase64" "false" | toString) "true" }}
  {{ $key }}: "{{ toString $value.value }}"
  {{- else }}
  {{ $key }}: "{{ toString $value.value | b64enc }}"
  {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard OpenShift route as a common alternative to ingresses.
This object is completely optional, that is, you can omit it in the values file
or include it via .Values.openshiftRoute at will.

(Adapted from appuio/openshift-route v1.1.4 (https://charts.appuio.ch), see
also ArtifactHub)
*/}}
{{- define "common-tpl-lib-2.7.0.openshift.route" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- if eq (.Values | merge (dict) | dig "openshiftRoute" "enabled" "false" | toString) "true" }}
{{- $fullName := include "common-tpl-lib-2.7.0.fullname" . }}
# Library definition: common-tpl-lib-2.7.0.openshift.route
apiVersion: route.openshift.io/v1
kind: Route
metadata:
  name: {{ $fullName }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
  {{- with .Values.openshiftRoute.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- with .Values.openshiftRoute }}
  host: {{ .host | default "" }}
  path: {{ .path }}
  wildcardPolicy: {{ .wildcardPolicy | default "None" }}
  port:
    targetPort: {{ dig "service" "targetPort" "http" . }}
  {{- if eq (dig "tls" "enabled" "false" . | toString) "true" }}
  tls:
    {{- with .tls }}
    termination: {{ .termination | default "edge" }}
    insecureEdgeTerminationPolicy: {{ .insecureEdgeTerminationPolicy | default "Redirect" }}
    {{- with .key }}
    key: |-
      {{- toString . | nindent 6 }}
    {{- end }}
    {{- with .certificate }}
    certificate: |-
      {{- toString . | nindent 6 }}
    {{- end }}
    {{- with .caCertificate }}
    caCertificate: |-
      {{- toString . | nindent 6 }}
    {{- end }}
    {{- with .destinationCACertificate }}
    destinationCACertificate: |-
      {{- toString . | nindent 6 }}
    {{- end }}
    {{- end }}
  {{- end }}
  to:
    kind: Service
    name: {{ dig "service" "name" $fullName . }}
    weight: {{ dig "service" "weight" 100 . }}
  {{- with .alternateBackends }}
  alternateBackends:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- end }}
{{- if eq (.Values.openshiftRoute.helmfixEnabled | default "false" | toString) "true" }}
{{/*
Fix for OpenShift routes related Helm3 issues. May be sensible to keep for now.
(Adapted from appuio/openshift-route v1.1.4 (https://charts.appuio.ch), see
also ArtifactHub)

More info:
- https://github.com/openshift/origin/issues/24060
- https://github.com/helm/helm/issues/6830
- ... and in particular: https://github.com/openshift/origin/issues/24060#issuecomment-574422393
*/}}
status:
  ingress:
    - host: ""
{{- end }}
{{- end }}
{{- end }}

{{/*
Define a map of ExternalSecret Kubernetes objects (CRD) to deploy.
*/}}
{{- define "common-tpl-lib-2.7.0.externalsecrets" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- $fullname := include "common-tpl-lib-2.7.0.fullname" . }}
{{- if .Values.externalSecrets }}
{{- $default_spec := dict "secretStoreRef" (dict "kind" "ClusterSecretStore" "name" "cluster-secret-store") }}
{{- $spec := merge (dig "common" (dict) .Values.externalSecrets) $default_spec }}
{{/* You should supply a prefix according to your stage. If you forget, then thze default "dev/namespace" will be used */}}
{{- $prefix := dig "prefix" (print "dev/" .Release.Namespace "/") .Values.externalSecrets }}
{{- range $name, $obj := (.Values.externalSecrets.entries | default dict) }}
# Library definition: common-tpl-lib-2.7.0.externalsecrets
apiVersion: external-secrets.io/v1
kind: ExternalSecret
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" $ }}-{{ $name }}
spec:
{{- if kindIs "string" $obj }}
  {{- merge (dict "dataFrom" (list (dict "extract" (dict "key" (print $prefix $obj))))) $spec | toYaml | nindent 2 }}
{{- else }}
  {{- merge $obj $spec | toYaml | nindent 2 }}
{{- end }}
---
{{- end }}
{{- end }}
{{- end }}

{{/*
Define a standard pod disruption budget.
*/}}
{{- define "common-tpl-lib-2.7.0.poddisruptionbudget" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- $podDisruptionBudget := .Values.podDisruptionBudget | default dict }}
{{- $enabled := true }}
{{- if hasKey $podDisruptionBudget "enabled" }}
{{- /* Convert to a string so that templating directives such as
global.podDisruptionBudget.enabled=false
podDisruptionBudget.enabled="{{ .Values.global.podDisruptionBudget.enabled }}"
are supported in the values.yaml file. */}}
{{- $enabled = $podDisruptionBudget.enabled | toString | eq "true" }}
{{- end }}
{{- /* Define a dedicated $enabled variable instead of directly using
{{- if $podDisruptionBudget.enabled | default true }} ...
because a user-defined setting podDisruptionBudget.enabled=false would end up in
the default branch and make the if condition unwantedly evaluate to true. */}}
{{- if $enabled }}
# Library definition: common-tpl-lib-2.7.0.poddisruptionbudget
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
spec:
  {{- /* Compare with nil (null or not present in YAML) to allow user to
  nullify a setting that was already made in a dependency chart. */}}
  {{- if and (ne $podDisruptionBudget.minAvailable nil) (ne $podDisruptionBudget.maxUnavailable nil) }}
  {{- fail "podDisruptionBudget: minAvailable and maxUnavailable must not be defined at the same time" }}
  {{- else if ne $podDisruptionBudget.minAvailable nil }}
  minAvailable: {{ $podDisruptionBudget.minAvailable }}
  {{- else if ne $podDisruptionBudget.maxUnavailable nil }}
  maxUnavailable: {{ $podDisruptionBudget.maxUnavailable }}
  {{- else }}
  maxUnavailable: 1
  {{- end }}
  selector:
    matchLabels:
      {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 6 }}
{{- end }}
{{- end }}

{{/*
Define a ServiceMonitor for prometheus-operator monitoring.
*/}}
{{- define "common-tpl-lib-2.7.0.servicemonitor" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- $serviceMonitor := .Values.serviceMonitor | default dict }}
{{- if eq ($serviceMonitor.enabled | default "false" | toString) "true" }}
# Library definition: common-tpl-lib-2.7.0.servicemonitor
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: {{ include "common-tpl-lib-2.7.0.fullname" . }}
  labels:
    {{- include "common-tpl-lib-2.7.0.labels" . | nindent 4 }}
    {{- with $serviceMonitor.additionalLabels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  selector:
    matchLabels:
      {{- include "common-tpl-lib-2.7.0.selectorLabels" . | nindent 6 }}
  endpoints:
    {{- $defaultEndpoint := dict "port" "metrics" "path" "/metrics" "interval" "60s" }}
    {{ $endpoint := $serviceMonitor.endpoint | default dict }}
    - {{ merge $endpoint $defaultEndpoint | toYaml | nindent 6 | trim }}
{{- end }}
{{- end }}

{{/*
Define an array of additional Kubernetes objects to deploy. These are expected
to follow the standard Kubernetes syntax.
*/}}
{{- define "common-tpl-lib-2.7.0.extradeploy" -}}
{{- include "common-tpl-lib-2.7.0.tpl.all.values" . }}
{{- range $obj := .Values.extraDeploy }}
# Library definition: common-tpl-lib-2.7.0.extradeploy
{{ toYaml $obj }}
---
{{- end }}
{{- end }}

{{/*
Render all the objects defined by the library into a single file.
*/}}
{{- define "common-tpl-lib-2.7.0.objects" -}}
{{ include "common-tpl-lib-2.7.0.deployment" . }}
---
{{ include "common-tpl-lib-2.7.0.statefulset" . }}
---
{{ include "common-tpl-lib-2.7.0.configmaps.env" . }}
---
{{ include "common-tpl-lib-2.7.0.secrets.env" . }}
---
{{ include "common-tpl-lib-2.7.0.configmaps.files" . }}
---
{{ include "common-tpl-lib-2.7.0.secrets.files" . }}
---
{{ include "common-tpl-lib-2.7.0.hpa" . }}
---
{{ include "common-tpl-lib-2.7.0.ingress" . }}
---
{{ include "common-tpl-lib-2.7.0.pv" . }}
---
{{ include "common-tpl-lib-2.7.0.pvc" . }}
---
{{ include "common-tpl-lib-2.7.0.service" . }}
---
{{ include "common-tpl-lib-2.7.0.serviceaccount" . }}
---
{{ include "common-tpl-lib-2.7.0.poddisruptionbudget" . }}
---
{{ include "common-tpl-lib-2.7.0.servicemonitor" . }}
---
{{ include "common-tpl-lib-2.7.0.openshift.route" . }}
---
{{ include "common-tpl-lib-2.7.0.externalsecrets" . }}
---
{{ include "common-tpl-lib-2.7.0.extradeploy" . }}
{{- end }}
