{{/*
Validate that all resource requests and limits are set

Usage:
This template checks if CPU/memory requests and limits are properly configured
for a container. For configuration examples, see the README.md documentation.
*/}}
{{- define "common-tpl-lib-2.7.0.resourceValidations" -}}

  {{- if and .Values.global .Values.global.validations -}}
    {{- if not .Values.resources -}}
      {{- fail "Resource validation failed. 'resources' configurations must be defined" -}}
    {{- end -}}
    {{- if not (.Values.resources.enabled | toString | eq "true") -}}
      {{- fail "Resource validation failed. 'resources.enabled' must be set to true" -}}
    {{- end -}}

    {{- $missing := list -}}
    {{- if eq .Values.resources.requests nil -}}
      {{- $missing = append $missing "resources.requests.cpu" -}}
      {{- $missing = append $missing "resources.requests.memory" -}}
      {{- $missing = append $missing "resources.requests.ephemeral-storage" -}}
    {{- else -}}
      {{- if not .Values.resources.requests.cpu -}}
        {{- $missing = append $missing "resources.requests.cpu" -}}
      {{- end -}}
      {{- if not .Values.resources.requests.memory -}}
        {{- $missing = append $missing "resources.requests.memory" -}}
      {{- end -}}
      {{- if not (index .Values.resources.requests "ephemeral-storage") -}}
        {{- $missing = append $missing "resources.requests.ephemeral-storage" -}}
      {{- end -}}
    {{- end -}}
    {{- if eq .Values.resources.limits nil -}}
      {{- $missing = append $missing "resources.limits.memory" -}}
      {{- $missing = append $missing "resources.limits.ephemeral-storage" -}}
    {{- else -}}
      {{- if not .Values.resources.limits.memory -}}
        {{- $missing = append $missing "resources.limits.memory" -}}
      {{- end -}}
      {{- if not (index .Values.resources.limits "ephemeral-storage") -}}
        {{- $missing = append $missing "resources.limits.ephemeral-storage" -}}
      {{- end -}}
    {{- end -}}

    {{- if $missing -}}
      {{- fail (printf "Resource validation failed. Missing: %s" (join ", " $missing)) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*
Validate that all required probe configurations are set

Usage:
This template checks if required probe configurations are properly configured
in a container. For configuration examples, see the README.md documentation.
*/}}
{{- define "common-tpl-lib-2.7.0.probeValidations" -}}

  {{- if and .Values.global .Values.global.validations -}}
    {{- if not .Values.probes -}}
      {{- fail "Probe validation failed. 'probes' configurations must be defined" -}}
    {{- end -}}
    {{- if not (.Values.probes.enabled | toString | eq "true") -}}
      {{- fail "Probe validation failed. 'probes.enabled' must be set to true" -}}
    {{- end -}}

    {{- $missing := list -}}
    {{- $probes := list "startupProbe" "readinessProbe" "livenessProbe" -}}
    {{- $requiredFields := list "initialDelaySeconds" "periodSeconds" "timeoutSeconds" "failureThreshold" -}}
    {{- range $probe := $probes -}}
      {{- $probeConfig := index $.Values.probes $probe -}}
      {{- if eq $probeConfig nil -}}
        {{- $missing = append $missing (printf "probes.%s" $probe) -}}
      {{- else -}}
        {{- range $field := $requiredFields -}}
          {{- $fieldValue := index $probeConfig $field -}}
          {{- if or (eq $fieldValue nil) (and (kindIs "string" $fieldValue) (eq $fieldValue "")) -}}
            {{- $missing = append $missing (printf "probes.%s.%s" $probe $field) -}}
          {{- end -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}

    {{- if $missing -}}
      {{- fail (printf "Probe validation failed. Missing: %s" (join ", " $missing)) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

